

public interface Constants {

    int STR_SIZE = 20;      // tamaño maximo de las cadenas
    int SIN_ASIGNAR = -1;   // registro no encontrado

}
