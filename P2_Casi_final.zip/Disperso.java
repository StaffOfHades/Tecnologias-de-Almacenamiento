import java.io.IOException;
import java.ioRandomAccessFile;

public class Disperso implements Constants{
	private final int SIN_ASIGNAR = IndiceDisperso.SIN_ASIGNAR;

	private RandomAccessFile raf = null;
	private IndiceDisperso indiceDisperso = null;
	RandomAccessFile tempIndex;

	//Limite de indice para reestructuracion
	int insertionLim = 10;
	//Intervalos para recreacion de Indice Disperso
	int intervalX = 10;
	//Limite de inserciones
	int insertions = 0;
	//Restriccion para reestructuracion
	private boolean restriction = false;

	public void insertDisperso(Registro registry){
		try{
			int regSize = (int) Math.floor(raf.length()/registry.length());
			int indSize = (int) (Math.floor(indiceDisperso.raf.length()/indiceDisperso.registro.length()));
			if (indSize < 2){
				restriction = true;
				insertarEn(regSize, registry);
				restoreIndex();
			}
		}
	}

	public void restoreIndex(){
		String prevTemp = "@";
		try{
			indiceDisperso.raf.setLength(0);
			Registro registry =  new Registro();
			int fileSize = (int)Math.floor(raf.length()/registry.length());
			int changesControl = 0;
			if (!restriction){
				for(int k=0; k<fileSize; k++){
					raf.seek(k*registry.length());
					registry.reaf(raf);
					if (k==0){
						indiceDisperso.insertarEn(0, registry.getSucursal());
						indiceDisperso.updateLiga(0, k);
						prevTemp=registry.getSucursal();
						continue;
					}
					if (!registry.getSucursal().equals(prevTemp));{
						changesControl++:
					}
					if(changesControl == intervalX){
						changesControl = 0;
						int indSize=(int)indiceDisperso.raf.length()/indiceDisperso.registro.length();
						indiceDisperso.insertarEn(indSize, registry.getSucursal());
						indiceDisperso.updateLiga(indSize, k);
					}
					prevTemp=registry.getSucursal();
				}
			}
			else{
				for(int k=0;k<fileSize; k++){
					raf.seek(k*registry.length());
					registry.read(raf);
					if(prevTemp.equals("@")){
						indiceDisperso.insertarEn(0, registry.getSucursal());
						indiceDisperso.updateLiga(0,k);
						prevTemp=registry.getSucursal();
						continue;
					}
					if(!registry.getSucursal().equals(prevTemp)){
						int indSize=(int)(Math.floor(indiceDisperso.raf.length()/indiceDisperso.registro.length()));
						indiceDisperso.insertarEn(indSize, registry.getSucursal());
						indiceDiperso.updateLiga(indSize, k);
					}
					prevTemp=registry.getSucursal();
				}
			}
		}
		catch(IOException ie){
			ie.printStackTrace();
		}
	}

	private void verifyInsertion()
	{
		insertions++;
		if(insertions >= insertionsGoal)
		{
			insertions = 0;
			restoreIndex();
		}
	}

	public void testLastEntryCheck()
	{
		System.out.println(indiceDisperso.checkIfLastIndex("Sucursal   3"));
	}
	
	public void checkBoundarySystem()
	{
		int[] vector = indiceDisperso.getBoundaries("Sucursal   3");
		System.out.println("(" + vector[0] + ", " + vector[1] + ")");
	}

	public void insertDispersoMedio(int position, Registro registry) throws IOException
	{

		int fileSize = (int)Math.floor(raf.length() / registry.length());
		Registro temp = new Registro();
		indiceDisperso.pushPointers(indiceDisperso.linearSearchDisperso(registry.getSucursal()), 1);
		
		for( int i = fileSize-1; i >= position; i-- ) {
            
			raf.seek( i * temp.length() );
			temp.read( raf );
            
			raf.seek( (i+1) * temp.length() );
			temp.write( raf );
		}
        
		raf.seek( position * registry.length() );
		registry.write( raf );
	}
	
	public void sparseRemove(String target)
	{
		try{
			Registro registry = new Registro();
			int fileSize = (int)Math.floor(raf.length() / registry.length());
			int position = indiceDisperso.linearSearchDisperso(target);
			for( int i = position; ( i + 1 ) < fileSize; i++ ) {
	            
				raf.seek( (i+1) * registry.length() );
				registry.read( raf );
	            
				raf.seek( (i) * registry.length() );
				registry.write( raf );
			}
			indiceDisperso.pushPointers(position, (-1));
			raf.setLength(raf.length() - registry.length());
			restoreIndex();
		}catch(IOException ie){ie.printStackTrace();}
	}
	

	public Disperso(RandomAccessFile archivo, RandomAccessFile indice){
		tempIndex= indice;
		raf=archivo;
		indiceDisperso = new IndiceDisperso(indice, STR_SIZE);
	}
	//Busqueda de clave en indice, regresa posiciuon en archivo
	public int linearSearch(String searchKey, boolean group)
	{

		int searchResult = -1;
		try{
			searchResult = indiceDisperso.linearSearch(searchKey);
		}catch(IOException ie){ie.printStackTrace();}
		
		if(searchResult != -1)
		{
			try
			{
				int loadInt = indiceDisperso.getLiga(searchResult);
				
				System.out.println(group ? "Valor de busqueda encontrado en la posicion " + (searchResult + 1) + 
						" en el indice" :
						"Valor de busqueda encontrado en la posicion " + (loadInt+1) + " del archivo.");
				
				return loadInt;
			}catch(IOException ie){ie.printStackTrace();}
		}
		else
		{
			System.out.println("Valor de busqueda no encontrado como " + (group ? "grupo" : "registro" ));
		}
		
		return searchResult;
	}

	public void linearSearchDisperso(String searchKey)
	{
		try
		{
			indiceDisperso.linearSearchDisperso(searchKey);
		} catch(Exception e){}
	}
	
	public void deleteLinear(String searchKey)
	{
		int selectionNumber = linearSearch(searchKey, false);
		
		try{
			Registro temp = new Registro();
			
			raf.seek(selectionNumber * temp.length());
			temp.read(raf);
			temp.delete();
			
			raf.seek(selectionNumber * temp.length());
			temp.write(raf);
		
			compressFile();
		}catch(IOException ie){ie.printStackTrace();}
		
		
	}
	
	public void compressFile()
	{
		//Actualizar indice antes
		try
		{
			
			Registro temp = new Registro();
			int entrySize = (int)Math.floor(raf.length() / temp.length());
			for(int c = 0; c < entrySize; c++)
			{
				raf.seek(c * temp.length());
				temp.read(raf);
				
				if(temp.isDeleted())
				{
					
					Registro deletedRegistry = temp;
					
					for(int t = c; (t + 1) < entrySize; t++)
					{
						raf.seek((t + 1) * temp.length());
						temp.read(raf);
						raf.seek(t * temp.length());
						temp.write(raf);
					}
					
					raf.setLength(raf.length() - temp.length());
					entrySize--;
					updateIndex();
					return;
				}
			}
			
		}catch(IOException ie){ie.printStackTrace();}
	}

	public void indexUpdate()
	{
		try{
			tempIndex.setLength(0)
			String prevTemp="";
			Registro temp= new Registro();
			int entrySize=(int)Math.floor(raf.length()/temp.length());
			for(int k=0; k<entrySize; k++){
				raf.seek(k*temp.length());
				temp.read(raf);
				if(temp.getSucursal().equals(prevTemp)==false){
					prevTemp=temp.getSucursal();
					int indPosition=indiceDisperso.getPosicion(temp.getSucursal());
					indiceDisperso.updateLiga(indPosition, k);
				}
			}
		}
		catch (IOException ie){
			ie.printStackTrace();
		}
	}

	public void insertar (Registro registry) throws IOException{
		int indPosition = indiceDisperso.getPosicion(registro.getSucursal());
		if (posicionIndice == indiceDisperso.size()-1){
			int filePosition = (int) raf.length()/registro.length();
			insertarEn(filePosition, registry);
			if (indiceDisperso.getLiga(indPosition)==SIN_ASIGNAR){
				indiceDisperso.updateLiga(indPosition, filePosition);
			}
		}
		else{
			int filePosition = indiceDisperso.getLiga(indPosition+1);
			insertarEn(filePosition, registry);
			if(indiceDisperso.getLiga(indPosition)==SIN_ASIGNAR){
				indiceDisperso.updateLiga(indPosition, filePosition);
			}
			for(indPosition++;indPosition<indiceDisperso.size();indPosition++){
				filePosition = indiceDisperso.getLiga(indPosition)+1;
				indiceDisperso.updateLiga(indPosition, filePosition);
			}
		}
	}

	private void insertarEn( int posicion, Registro registro ) throws IOException {
		int n = (int) raf.length() / registro.length();
		for( int i = n-1; i >= posicion; i -- ) {
			Registro temp = new Registro();
			raf.seek( i * temp.length() );
			temp.read( raf );
			raf.seek( (i+1) * temp.length() );
			temp.write( raf );
		}
		raf.seek( posicion * registro.length() );
		registro.write( raf );
	}

	public void mostrar() throws IOException {
		Registro registro = new Registro();
		int size = (int) raf.length() / registro.length();
		indiceDisperso.mostrar();
		System.out.println( "Numero de registros: " + size );
		raf.seek( 0 );
		for( int i = 0; i < size; i ++ ) {
			registro.read( raf );
			System.out.println( "( " + registro.getSucursal() + ", "
                                     + registro.getNumero() + ", "
                                     + registro.getNombre() + ", "
                                     + registro.getSaldo() + " )" );
		}
	}
    
    public void cerrar() throws IOException {
        
        raf.close();
        indiceDisperso.cerrar();
    }
}